# Snake Game Using HTML, CSS, JS

![project-4](https://user-images.githubusercontent.com/62342666/206780641-a1d3e859-4fe1-40d7-b4ef-0a03049f1a43.png)
